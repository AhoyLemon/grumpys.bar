<?php if(!defined('KIRBY')) exit ?>

username: lemon
password: >
  $2y$10$iHZeASRLEAef2S56igN.p.qb28/dfjFEPjlJ9FtCrbSCC6.E2ZyUu
email: lemon@hirelemon.com
language: en
role: admin
history:
  - home/downtown
